#---------------------------------------------------#
#Title: Module6Work.py
#Dev: Chris Tanimoto
#Date: November 6, 2016
#Desc: Homework for Module 6
# ChangeLog:
# 1. 11/6/2016 CTT - Added methods and class to fit requirements for module 6 homework
#---------------------------------------------------#

#Create the class
class modsix:
    #Create a method to open the text file specified in step one of the homework and log it's values
    def openfile():
        objfile = open("Todo.txt")
        modsix.list = []
        for line in objfile:
            parseline = line.strip('\n').split(',')
            #Store the value of the line in a dictionary
            dicline = {"Task":parseline[0],"Priority":parseline[1]}
            #Store the dictionary into a list
            modsix.list.insert(0,dicline)
        objfile.close()
    #This method is used as it is a part of the grading rubric, it is a break from the previous
    #code, but necessary to get full marks on this assignment.

    def listinfile():
        print('Here are the objects currently in the list:')
        for key in modsix.list:
            print(key)

    #This section creates methods to add and remove lines from the list.  It is new from last week, but created
    #because it is needed to get full marks on the assignment.
    def add():
        task = input("Enter a task to be added:")
        priority = input("Enter the priority of the task you just added:")
        diclineadd = {"Task": task, "Priority": priority}
        modsix.list.insert(0, diclineadd)

    def remove():
        print("Which task should be removed?")
        for dic in modsix.list:
            print(modsix.list.index(dic), dic)
        test = int(input("State the Number on the lefthand side of the line you want removed:"))
        modsix.list.pop(test)
    #This portion creates a method that prints out all values included in the list and details the user's options
    def AddRemoveLoop():
        while(True):
            print("Choose 1 to Add task")
            print("Choose 2 to Remove task")
            print("Choose 3 to Save all tasks to the Todo.txt file and exit!")
            command = input("Enter your choice here:")
            #This section allows the users to add new values to the list
            if command == '1': modsix.add()

            #This section allows users to remove values from the list
            if command =='2': modsix.remove()

            #this section breaks the loop and allows the program to continue
            if command == '3': break
            print('Here are the objects currently in the file:')
            for key in modsix.list:
                print(key)

    # This section creates a method that opens the file that persists the data and removes any existing values.
    def openlisttosave():
        modsix.objfile1 = open("Todo.txt", "w")

    # This section creates a method that persists the values in the text file for future use.
    def persistdata():
        for t in modsix.list:
            task = t['Task']
            priority = t['Priority']
            value = str(task + ',' + priority + '\n')
            row = (value.strip("'").strip("[").strip("]"))
            modsix.objfile1.write(row)
        modsix.objfile1.close()
        print('Thank you for using the program, your data has been saved.')


modsix.openfile()
modsix.listinfile()
modsix.AddRemoveLoop()
modsix.openlisttosave()
modsix.persistdata()

