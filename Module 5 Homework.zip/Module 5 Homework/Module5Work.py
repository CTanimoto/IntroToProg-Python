#---------------------------------------------------#
#Title: Module5Work.py
#Dev: Chris Tanimoto
#Date: October 30, 2016
#Desc: Homework for Module 5
# ChangeLog: N/A
#---------------------------------------------------#

#Open the text file specified in step one of the homework and log it's values
objfile = open("Todo.txt")
list = []
for line in objfile:
    parseline = line.strip('\n').split(',')
    #Store the value of the line in a dictionary
    dicline = {"Task":parseline[0],"Priority":parseline[1]}
    #Store the dictionary into a list
    list.insert(0,dicline)
objfile.close()

#This portion prints out all values included in the list and details the user's options
print('Here are the objects currently in the list:')
for key in list:
    print(key)
while(True):
    print("Choose 1 to Add task")
    print("Choose 2 to Remove task")
    print("Choose 3 to Save all tasks to the Todo.txt file and exit!")
    command = input("Enter your choice here:")
    #This section allows the users to add new values to the list
    if command == '1':
        task = input("Enter a task to be added:")
        priority = input("Enter the priority of the task you just added:")
        diclineadd = {"Task":task,"Priority":priority}
        list.insert(0,diclineadd)
    #This section allows users to remove values from the list
    if command =='2':
        print("Which task should be removed?")
        for dic in list:
            print(list.index(dic),dic)
        test = int(input("State the Number on the lefthand side of the line you want removed:"))
        list.pop(test)
    #this section breaks the loop and allows the program to continue
    if command == '3': break
    print('Here are the objects currently in the file:')
    for key in list:
        print(key)
#this section opens the file that persists the data and removes any existing values.
objfile1 = open("Todo.txt","w")
objfile1.truncate()
#This section persists the values in the text file for future use.
for t in list:
    task = t['Task']
    priority = t['Priority']
    value = str(task+','+priority+'\n')
    row =(value.strip("'").strip("[").strip("]"))
    objfile1.write(row)
objfile1.close()